# Student Grade Management System

**Domain:** Java Programming  
**Project Type:** Console-based Java application

## Features
- Accepts the number of students, student names, and marks.
- Stores student records using `ArrayList`.
- Calculates average, highest, and lowest scores.
- Displays a summary report with each student's marks and grade.
- Validates student count and marks (0–100).

## Requirements
- JDK 8 or later
- Eclipse IDE, IntelliJ IDEA, or terminal

## How to run in Eclipse
1. Open Eclipse and create a Java Project named `StudentGradeManagement`.
2. In the `src` folder, create a class named `StudentGradeManagement`.
3. Copy the code from `src/StudentGradeManagement.java` into the class.
4. Run the file as a Java Application.
5. Enter the number of students, then each student's name and marks.

## How to run from a terminal
From the `src` folder:

```bash
javac StudentGradeManagement.java
java StudentGradeManagement
```

## Example test data
- Rahul — 80
- Priya — 90
- Amit — 70

Expected summary values:
- Average Marks: 80.00
- Highest Score: 90.00 (Priya)
- Lowest Score: 70.00 (Amit)

## Grade scale used
- 90–100: A+
- 80–89.99: A
- 70–79.99: B
- 60–69.99: C
- 50–59.99: D
- 35–49.99: Pass
- Below 35: Fail

Note: The task requires average, highest score, lowest score, and a summary report. The grade scale is an additional feature for clarity.
