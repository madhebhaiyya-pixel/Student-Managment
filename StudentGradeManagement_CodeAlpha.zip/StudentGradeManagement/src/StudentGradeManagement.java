import java.util.ArrayList;
import java.util.Scanner;

public class StudentGradeManagement {

    static class Student {
        private final String name;
        private final double marks;

        public Student(String name, double marks) {
            this.name = name;
            this.marks = marks;
        }

        public String getName() {
            return name;
        }

        public double getMarks() {
            return marks;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        System.out.println("========================================");
        System.out.println("     STUDENT GRADE MANAGEMENT SYSTEM");
        System.out.println("========================================");

        int numberOfStudents = readPositiveInt(scanner, "Enter number of students: ");

        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println("\nEnter details for student " + (i + 1) + ":");

            String name;
            do {
                System.out.print("Student name: ");
                name = scanner.nextLine().trim();
                if (name.isEmpty()) {
                    System.out.println("Name cannot be empty. Please try again.");
                }
            } while (name.isEmpty());

            double marks = readMarks(scanner, "Marks (0-100): ");
            students.add(new Student(name, marks));
        }

        double total = 0.0;
        Student highest = students.get(0);
        Student lowest = students.get(0);

        for (Student student : students) {
            total += student.getMarks();

            if (student.getMarks() > highest.getMarks()) {
                highest = student;
            }
            if (student.getMarks() < lowest.getMarks()) {
                lowest = student;
            }
        }

        double average = total / students.size();

        System.out.println("\n\n============== STUDENT SUMMARY REPORT ==============");
        System.out.printf("%-5s %-25s %10s %10s%n", "No.", "Student Name", "Marks", "Grade");
        System.out.println("----------------------------------------------------");

        for (int i = 0; i < students.size(); i++) {
            Student student = students.get(i);
            System.out.printf("%-5d %-25s %10.2f %10s%n",
                    i + 1, student.getName(), student.getMarks(), getGrade(student.getMarks()));
        }

        System.out.println("----------------------------------------------------");
        System.out.printf("Average Marks : %.2f%n", average);
        System.out.printf("Highest Score : %.2f (%s)%n", highest.getMarks(), highest.getName());
        System.out.printf("Lowest Score  : %.2f (%s)%n", lowest.getMarks(), lowest.getName());
        System.out.println("====================================================");

        scanner.close();
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            try {
                int value = Integer.parseInt(input);
                if (value > 0) {
                    return value;
                }
                System.out.println("Please enter a number greater than 0.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a whole number.");
            }
        }
    }

    private static double readMarks(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            try {
                double marks = Double.parseDouble(input);
                if (marks >= 0 && marks <= 100) {
                    return marks;
                }
                System.out.println("Marks must be between 0 and 100.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    private static String getGrade(double marks) {
        if (marks >= 90) return "A+";
        if (marks >= 80) return "A";
        if (marks >= 70) return "B";
        if (marks >= 60) return "C";
        if (marks >= 50) return "D";
        if (marks >= 35) return "Pass";
        return "Fail";
    }
}
